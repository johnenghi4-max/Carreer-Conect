document.addEventListener("DOMContentLoaded", function() {

  const mainContent = document.getElementById("main-content");

  // Load sidebar
  fetch("data/notifications.json")
    .then(res => res.json())
    .then(notifications => {
      const ul = document.getElementById("notifications-list");
      notifications.forEach(n => {
        const li = document.createElement("li");
        li.className = "flex justify-between items-start gap-4";
        li.innerHTML = `<a href="${n.link}" class="text-sm font-medium text-slate-700 dark:text-slate-300 hover:text-primary">${n.title}</a>
                        <span class="text-xs text-slate-400 dark:text-slate-500 whitespace-nowrap">${n.date}</span>`;
        ul.appendChild(li);
      });
    });

  fetch("data/posts.json")
    .then(res => res.json())
    .then(posts => {
      const ul = document.getElementById("posts-list");
      posts.forEach(p => {
        const li = document.createElement("li");
        li.className = "flex items-center gap-4";
        li.innerHTML = `<img src="${p.img}" alt="${p.title}" class="w-16 h-16 rounded-lg object-cover">
                        <div>
                          <a href="${p.link}" class="font-semibold text-slate-800 dark:text-slate-200 hover:text-primary">${p.title}</a>
                          <p class="text-sm text-slate-500 dark:text-slate-400">${p.date}</p>
                        </div>`;
        ul.appendChild(li);
      });
    });

  // Menu button click
  document.querySelectorAll(".menu-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      const tab = btn.dataset.tab;
      loadTab(tab);
      // Highlight active menu
      document.querySelectorAll(".menu-btn").forEach(b => b.classList.remove("font-bold", "text-primary"));
      btn.classList.add("font-bold", "text-primary");
    });
  });

  // Default tab: home
  loadTab("home");

  async function loadTab(tab) {
    mainContent.innerHTML = ""; // clear content

    if(tab === "home") {
      mainContent.innerHTML = `<h2 class="text-2xl font-bold mb-4">Home - Latest Updates</h2>`;

      // Load Jobs
      const jobs = await fetch("data/jobs.json").then(res => res.json());
      const jobsContainer = document.createElement("div");
      jobsContainer.className = "mb-8";
      jobsContainer.innerHTML = `<h3 class="text-xl font-bold mb-2">Jobs</h3>`;
      jobs.forEach(job => {
        const div = document.createElement("div");
        div.className = "bg-white dark:bg-slate-800 p-4 rounded shadow mb-2 hover:shadow-md transition";
        div.innerHTML = `<h4 class="font-semibold">${job.title}</h4>
                         <p>${job.company} - ${job.location}</p>
                         <a href="${job.link}" class="text-primary hover:underline">Apply</a>`;
        jobsContainer.appendChild(div);
      });
      mainContent.appendChild(jobsContainer);

      // Load Admit Cards
      const admitCards = await fetch("data/admitcards.json").then(res => res.json());
      const admitContainer = document.createElement("div");
      admitContainer.className = "mb-8";
      admitContainer.innerHTML = `<h3 class="text-xl font-bold mb-2">Admit Cards</h3>`;
      const admitTable = document.createElement("table");
      admitTable.className = "w-full text-sm";
      admitTable.innerHTML = `<thead class="bg-slate-50 dark:bg-slate-700/50">
                                <tr>
                                  <th class="p-4 text-left font-semibold">Exam Name</th>
                                  <th class="p-4 text-left font-semibold">Release Date</th>
                                  <th class="p-4 text-left font-semibold">Download</th>
                                </tr>
                              </thead>`;
      const admitTbody = document.createElement("tbody");
      admitTbody.className = "divide-y divide-slate-200 dark:divide-slate-700";
      admitCards.forEach(c => {
        const tr = document.createElement("tr");
        tr.innerHTML = `<td class="p-4">${c.exam}</td>
                        <td class="p-4">${c.release_date}</td>
                        <td class="p-4"><a href="${c.link}" class="text-primary hover:underline">Download</a></td>`;
        admitTbody.appendChild(tr);
      });
      admitTable.appendChild(admitTbody);
      admitContainer.appendChild(admitTable);
      mainContent.appendChild(admitContainer);

      // Load Results
      const results = await fetch("data/results.json").then(res => res.json());
      const resultsContainer = document.createElement("div");
      resultsContainer.innerHTML = `<h3 class="text-xl font-bold mb-2">Results</h3>`;
      const resultsTable = document.createElement("table");
      resultsTable.className = "w-full text-sm";
      resultsTable.innerHTML = `<thead class="bg-slate-50 dark:bg-slate-700/50">
                                  <tr>
                                    <th class="p-4 text-left font-semibold">Exam Name</th>
                                    <th class="p-4 text-left font-semibold">Result Date</th>
                                    <th class="p-4 text-left font-semibold">Download</th>
                                  </tr>
                                </thead>`;
      const resultsTbody = document.createElement("tbody");
      resultsTbody.className = "divide-y divide-slate-200 dark:divide-slate-700";
      results.forEach(r => {
        const tr = document.createElement("tr");
        tr.innerHTML = `<td class="p-4">${r.exam}</td>
                        <td class="p-4">${r.result_date}</td>
                        <td class="p-4"><a href="${r.link}" class="text-primary hover:underline">PDF</a></td>`;
        resultsTbody.appendChild(tr);
      });
      resultsTable.appendChild(resultsTbody);
      resultsContainer.appendChild(resultsTable);
      mainContent.appendChild(resultsContainer);

    }
    else if(tab === "jobs") {
      const jobs = await fetch("data/jobs.json").then(res => res.json());
      mainContent.innerHTML = `<h2 class="text-2xl font-bold mb-4">Jobs</h2>`;
      const container = document.createElement("div");
      container.className = "space-y-4";
      jobs.forEach(job => {
        const div = document.createElement("div");
        div.className = "bg-white dark:bg-slate-800 p-4 rounded shadow hover:shadow-md transition";
        div.innerHTML = `<h4 class="font-semibold">${job.title}</h4>
                         <p>${job.company} - ${job.location}</p>
                         <a href="${job.link}" class="text-primary hover:underline">Apply</a>`;
        container.appendChild(div);
      });
      mainContent.appendChild(container);
    }
    else if(tab === "admitcards") {
      const admitCards = await fetch("data/admitcards.json").then(res => res.json());
      mainContent.innerHTML = `<h2 class="text-2xl font-bold mb-4">Admit Cards</h2>`;
      const table = document.createElement("table");
      table.className = "w-full text-sm";
      table.innerHTML = `<thead class="bg-slate-50 dark:bg-slate-700/50">
                           <tr>
                             <th class="p-4 text-left font-semibold">Exam Name</th>
                             <th class="p-4 text-left font-semibold">Release Date</th>
                             <th class="p-4 text-left font-semibold">Download</th>
                           </tr>
                         </thead>`;
      const tbody = document.createElement("tbody");
      tbody.className = "divide-y divide-slate-200 dark:divide-slate-700";
      admitCards.forEach(c => {
        const tr = document.createElement("tr");
        tr.innerHTML = `<td class="p-4">${c.exam}</td>
                        <td class="p-4">${c.release_date}</td>
                        <td class="p-4"><a href="${c.link}" class="text-primary hover:underline">Download</a></td>`;
        tbody.appendChild(tr);
      });
      table.appendChild(tbody);
      mainContent.appendChild(table);
    }
    else if(tab === "results") {
      const results = await fetch("data/results.json").then(res => res.json());
      mainContent.innerHTML = `<h2 class="text-2xl font-bold mb-4">Results</h2>`;
      const table = document.createElement("table");
      table.className = "w-full text-sm";
      table.innerHTML = `<thead class="bg-slate-50 dark:bg-slate-700/50">
                           <tr>
                             <th class="p-4 text-left font-semibold">Exam Name</th>
                             <th class="p-4 text-left font-semibold">Result Date</th>
                             <th class="p-4 text-left font-semibold">Download</th>
                           </tr>
                         </thead>`;
      const tbody = document.createElement("tbody");
      tbody.className = "divide-y divide-slate-200 dark:divide-slate-700";
      results.forEach(r => {
        const tr = document.createElement("tr");
        tr.innerHTML = `<td class="p-4">${r.exam}</td>
                        <td class="p-4">${r.result_date}</td>
                        <td class="p-4"><a href="${r.link}" class="text-primary hover:underline">PDF</a></td>`;
        tbody.appendChild(tr);
      });
      table.appendChild(tbody);
      mainContent.appendChild(table);
    }
    else if(tab === "about") {
      mainContent.innerHTML = `<h2 class="text-2xl font-bold mb-4">About Us</h2>
                               <p>CareerConnect is your portal for jobs, admit cards, results, and career guidance. We provide reliable resources for your career growth.</p>`;
    }
  }

});
