[
  {
    "exam": "State Public Service Commission Exam",
    "date": "2024-07-20",
    "link": "#"
  },
  {
    "exam": "Combined Graduate Level Exam",
    "date": "2024-07-15",
    "link": "#"
  },
  {
    "exam": "Banking Sector Recruitment Exam",
    "date": "2024-07-10",
    "link": "#"
  }
]
