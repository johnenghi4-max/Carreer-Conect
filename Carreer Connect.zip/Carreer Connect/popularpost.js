[
  {
    "title": "Top 5 Interview Questions",
    "image": "https://lh3.googleusercontent.com/aida-public/AB6AXuBarhdaqX38N7VormUB-4VjICyzf_9QIr7SM8x-9_J9uyX6Y73AM-zVu6pX5kP_iYLbHbforTydrwgOD9jNwrnaIZRSldMGBgfwsATA8abbTvD8ZCS7CLwrW_v3enh-jY9PT0iGbeXTQwjKkIAH8OnxlaD5bqC_jb_L-yUME56JnoBYxQ7dY6DYws3VZhyJ0KdFjY0y05Rd1wIRz8Y9iQtqJl2zygmbzIRwsFoLPn391VhZxoPFLNX0j9494p_EX01ScG0fPmzEHloN"
  },
  {
    "title": "Resume Writing Guide",
    "image": "https://lh3.googleusercontent.com/aida-public/AB6AXuDTuCimhoGC4gwvRdPDGbH-cr94hBrBTo4tKy_3xoHQK1AnP1iwqsc2re38bgWoFF-_ETB3sn1ClNwyveGY-gM-OxBT5IRLj6lVl9POnQ5Fj36ar_03tR99r0k7uV5lcgRpP8LTH3jUFQvH1ppsa-Nt1BkBT6XqXIgZtkKuWesz1l9DN-t6Gw5RA4b9bwgA7rI3MVktS62FDQFmo2HVNQDrcZkAM8p-141lcEaMEcucKxcbh6iL_Csga_Gk7pOoQHv-_EWAMFOmX9o4"
  },
  {
    "title": "Career Paths in Tech",
    "image": "https://lh3.googleusercontent.com/aida-public/AB6AXuBfWZj2nN1h9Sg_Q99BbHwFRofmY8BEch2N7LDrIGjVW9v6srJnUjVqCeWR0pDpRWTewpCfurFjCeUwTqheSogKKtJ_0BK2sug07Gm4qHpeT-a2xVSDpe4O4v7Vctk8EMoBAAzGBxg1v1d0ABGzSig_Sk295lFpiUGudFvkQ7tOqFDNI5ZMGuxDYwN71JlemjubbcIpKLlkblfFR1ne1UD_vjYjFZZBl1YZtnsU8YEdOYjnx74kElleBsE1SEl6J0JFOnwi8gJYEAyx"
  }
]
