[
  {
    "title": "Upcoming Job Fair in City Center",
    "date": "Jul 28"
  },
  {
    "title": "New Government Job Openings",
    "date": "Jul 27"
  },
  {
    "title": "Interview Tips and Tricks",
    "date": "Jul 26"
  }
]
